
package com.heahom.livetimediaglog;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    Button DOBbtn;
    TextView liveTextView;
    Calendar c = Calendar.getInstance();
    int curYear = c.get(Calendar.YEAR);
    int curMonth = c.get(Calendar.MONTH);
    int curDay = c.get(Calendar.DAY_OF_MONTH);
    String LivingTime;
    DatePickerDialog datePickerDialog;
    TimePickerDialog timePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DOBbtn = (Button) findViewById(R.id.DOBbtn);
        liveTextView = (TextView) findViewById(R.id.liveTextView);
    }

    public void onDOBBtnClick(View view) {
        datePickerDialog = new DatePickerDialog(MainActivity.this, dateSetListener, curYear, curMonth, curDay);
        datePickerDialog.show();
    }

    private final DatePickerDialog.OnDateSetListener dateSetListener = (view, year, month, dayOfMonth) -> {
        calLiveDay(year, month, dayOfMonth);
    };

    public void onTimeBtnClick(View view) {
        final Calendar cldr = Calendar.getInstance();
        int hour = cldr.get(Calendar.HOUR_OF_DAY);
        int minutes = cldr.get(Calendar.MINUTE);
        timePickerDialog = new TimePickerDialog(MainActivity.this, (tp, sHour, sMinute) -> {
            liveTextView.setText(sHour + ":" + sMinute);
        }, hour, minutes, true);
        timePickerDialog.show();
    }

    private void calLiveDay(int year, int month, int dayOfMonth) {
        // Perform your calculations for living time based on the selected date of birth.
        // Update the "LivingTime" variable or display it in the TextView as needed.
    }
    public void onExitBtnClick(View view) {
        confirmExitDialog();
    }

    private void confirmExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Exit");
        builder.setMessage("Are you sure you want to exit?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle exit action here, for example, finish the activity
                finish();
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Dismiss the dialog if "No" is clicked
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

}
